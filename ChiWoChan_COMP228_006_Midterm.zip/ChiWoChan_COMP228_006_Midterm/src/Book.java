public abstract class Book {
    String title;
    String description;
    String publisher;
    Double price;
    int year;

    //constructor
    public Book(String title, String description, String publisher, int year) {
        this.title = title;
        this.description = description;
        this.publisher = publisher;
        this.year = year;
    }

    //create a method to print book info
    public String toString() {
        return "Title: " + title + "\nDescription: " + description + "\nPublisher: " + publisher + "\nPrice: " + price + "\nYear: " + year;
    }

    //getter method
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }


    public String getPublisher() {
        return publisher;
    }

    public int getYear() {
        return year;
    }

    public void getPrice(double price) {
        this.price = price;
    }

    //setter methods
    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    public void setYear(int year) {
        this.year = year;
    }

    abstract public void setPrice(double price);

    abstract public String getGenre();
}
