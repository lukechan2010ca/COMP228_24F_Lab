public class ScienceBook extends Book {

    public ScienceBook(String title, String description, String publisher, int year) {
        super(title, description, publisher, year);
    }

    @Override
    public void setPrice(double price) {
        double discountedPrice = price * 0.9; // 10% discount
        super.getPrice(discountedPrice);
    }

    @Override
    public String getGenre() {
        return "Science";
    }
}
