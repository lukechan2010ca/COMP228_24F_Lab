import java.util.Scanner;

public class Main {
public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    // Input for ScienceBook
    System.out.print("Enter the Science Book Title: ");
    String scienceTitle = scanner.nextLine();

    System.out.print("Enter the Science Book Description: ");
    String scienceDescription = scanner.nextLine();

    System.out.print("Enter the Science Book Publisher: ");
    String sciencePublisher = scanner.nextLine();

    System.out.print("Enter the Science Book Year: ");
    int scienceYear = scanner.nextInt();

    System.out.print("Enter the Science Book Price: ");
    double sciencePrice = scanner.nextDouble();

    ScienceBook scienceBook = new ScienceBook(scienceTitle, scienceDescription, sciencePublisher, scienceYear);
    scienceBook.setPrice(sciencePrice);

    // Input for ChildrenBook
    scanner.nextLine(); // consume the newline character after nextDouble()

    System.out.print("Enter the Children Book Title: ");
    String childrenTitle = scanner.nextLine();

    System.out.print("Enter the Children Book Description: ");
    String childrenDescription = scanner.nextLine();

    System.out.print("Enter the Children Book Publisher: ");
    String childrenPublisher = scanner.nextLine();

    System.out.print("Enter the Children Book Year: ");
    int childrenYear = scanner.nextInt();

    System.out.print("Enter the Children Book Price: ");
    double childrenPrice = scanner.nextDouble();

    ChildrenBook childrenBook = new ChildrenBook(childrenTitle, childrenDescription, childrenPublisher, childrenYear);
    childrenBook.setPrice(childrenPrice);

    // Display book details
    System.out.println("\nScience Book Info:");
    System.out.println(scienceBook.toString() + "\nGenre: " + scienceBook.getGenre());

    System.out.println("\nChildren Book Info:");
    System.out.println(childrenBook.toString() + "\nGenre: " + childrenBook.getGenre());

    scanner.close();
    }
}
