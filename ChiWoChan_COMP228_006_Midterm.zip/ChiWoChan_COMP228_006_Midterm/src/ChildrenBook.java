public class ChildrenBook extends Book {

    public ChildrenBook(String title, String description, String publisher, int year) {
        super(title, description, publisher, year);
    }

    @Override
    public void setPrice(double price) {
        super.getPrice(price);  // Set the price directly
    }

    @Override
    public String getGenre() {
        return "Children";
    }
}
